import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig(({ mode }) => {
    const {
        VITE_ADMIN_PORT,
        VITE_ADMIN_HOST,
        VITE_ADMIN_API_PROXY_TARGET,
        VITE_MEDIA_BASE_URL,
    } = loadEnv(mode, __dirname, '');

    const apiProxyTarget = VITE_ADMIN_API_PROXY_TARGET ?? 'http://api:8000';

    return {
        plugins: [
            react(),
            {
                name: 'html-transform',
                    transformIndexHtml(html) {
                        return html.replace(/%VITE_MEDIA_BASE_URL%/g, VITE_MEDIA_BASE_URL || 'https://iieg.jalisco.gob.mx/acervo');
                    },
            }
        ],
        root: '.',
        server: {
            host: VITE_ADMIN_HOST ?? '0.0.0.0',
            port: Number(VITE_ADMIN_PORT ?? '3011'),
            strictPort: true,
            proxy: {
                '/api': {
                    target: apiProxyTarget,
                    // Keep localhost host header so backend redirects don't expose Docker-only hostnames.
                    changeOrigin: true,
                },
            },
            watch: {
                usePolling: true
            }
        },
        base: '/portal-admin/',
        build: {
            outDir: 'dist',
            sourcemap: process.env.NODE_ENV === 'development',
        },
        resolve: {
            alias: {
                '@': path.resolve(__dirname, './src'),
                '@components': path.resolve(__dirname, './src/components'),
                '@pages': path.resolve(__dirname, './src/pages'),
                '@layouts': path.resolve(__dirname, './src/layouts'),
                '@providers': path.resolve(__dirname, './src/providers'),
                '@assets': path.resolve(__dirname, './src/assets'),
                '@utils': path.resolve(__dirname, './src/utils'),
                '@hooks': path.resolve(__dirname, './src/hooks'),
                '@services': path.resolve(__dirname, './src/services'),
                '@contexts': path.resolve(__dirname, './src/contexts'),
                '@constants': path.resolve(__dirname, './src/constants'),
                '@router': path.resolve(__dirname, './src/router'),
            },
        },
    };
});