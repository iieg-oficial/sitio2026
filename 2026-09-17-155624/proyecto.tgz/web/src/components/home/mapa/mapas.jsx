import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router'
import api from '@services/apiService'
import './mapas.css'
import TrackedLink from '@components/blocks/boton'

const BASE_MEDIA_URL = import.meta.env.VITE_MEDIA_BASE_URL || 'https://iieg.jalisco.gob.mx/acervo'
const THUMB_BASE_URL = `${BASE_MEDIA_URL}/thumb/portal/mapas`
const DEFAULT_IMAGE = `${BASE_MEDIA_URL}/portal/img_postlink.png`

export default function Mapas() {
    const [mapas, setMapas] = useState([])
    const location = useLocation()
    const [isMobile, setIsMobile] = useState(false)
    const [loading, setLoading] = useState(false)    

    useEffect(() => {
        const fetchMapas = async () => {
            const response = await api.get('/mapas/random')            
            if (Array.isArray(response.data?.mapas)) {
                    setMapas(response.data.mapas)
                } else if (Array.isArray(response.data)) {
                    setMapas(response.data)
                }
        }


        const handleResize = () => {
            setIsMobile(window.innerWidth < 768)
        }

        handleResize()
        window.addEventListener('resize', handleResize)

        fetchMapas()

        return () => {
            window.removeEventListener('resize', handleResize)
        }
    }, [location])


    if (loading || !mapas || mapas.length === 0) {
        return null // O puedes retornar un skeleton / loader
    }

    const mapasFiltrados = isMobile ? mapas.slice(0, 1) : mapas
    
    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 extra:max-w-[1980px] mx-auto w-full">
            {mapasFiltrados.map((mapa) => {
                if (!mapa) return null
                
                const thumb = mapa.imagen 
                            ? mapa.imagen.substring(mapa.imagen.lastIndexOf('/') + 1) 
                            : null;
                const titulo = mapa?.titulo ?? '';

                const srcImagen = thumb 
                    ? `${THUMB_BASE_URL}/${thumb}?w=560` 
                    : DEFAULT_IMAGE;

                return (
                <TrackedLink to={`/galeria-de-mapas/${mapa.slug}`} key={mapa.id}>
                    <div key={mapa.id} className="overflow-hidden mapa h-60 sm:h-96 md:h-40 lg:h-60 xl:h-69 2xl:h-96 relative rounded-4xl">  
                
                        <img 
                            src={srcImagen}
                            alt={titulo} 
                            className='w-full h-full object-cover image-mapa'
                            onError={(e) => {
                                    if (!e.target.dataset.triedFallback) {
                                        e.target.dataset.triedFallback = 'true';
                                        e.target.src = mapa.imagen 
                                            ? mapa.imagen 
                                            : DEFAULT_IMAGE;
                                    } else {                                        
                                        e.target.onerror = null;
                                        e.target.src = DEFAULT_IMAGE;
                                    }
                                }}
                            />
                        <div className='info px-5 mt-2 inline-block text-sm text-[#6618a2]'>
                            
                                {titulo && <h3 className='text-white text-22 font-garet-bold font-800'>{titulo}</h3>}
                                
                                <div className='flex mb-5 mt-5 gap-2'>  
                                    {mapa.anyo ? <p className='text-14 font-bold rounded-xl py-2 px-5 bg-[#FFF2E5] text-tertiary border border-[#FF83004D]'>{mapa.anyo}</p> : null}                        
                                    {mapa.tipo ? <p className='text-14 font-bold rounded-xl py-2 px-5 bg-etiqueta-ter text-titulo border border-[#162A554D]'>{mapa.tipo}</p> : null}                                    
                                </div>
                                
                            
                        </div>
                    </div>
                </TrackedLink>
                );
            })}
        </div>
    )
}