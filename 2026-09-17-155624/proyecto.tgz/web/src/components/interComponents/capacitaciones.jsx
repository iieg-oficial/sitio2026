import { useParams } from 'react-router';
import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import api from '@services/apiService'
import CapacitacionesList from './capacitaciones_list';
import BackLink from './../pageComponents/Backlink'
import TrackedLink from '@components/blocks/boton'
import dayjs from 'dayjs'
import 'dayjs/locale/es'
import { SafeHtml } from '@components/SafeHtml';

dayjs.locale('es')

export default function Capacitaciones() {
    const { slug } = useParams(); // obtiene el id del elemento clicleable
    const [singleCapacitacion, setSingleCapacitacion] = useState(null);
    const [activeTab, setActiveTab] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchCapacitacion = async () => {
            try {
                const response = await api.get(`/cursos-public/slug/${slug}`);
                setSingleCapacitacion(response.data);
                setError(null);
            } catch (error) {
                console.error("Error al obtener la capacitación:", error);
                setError(error?.response?.data?.detail || error.message || 'Error al obtener la capacitación');
                setSingleCapacitacion(null);
            }
        }
        fetchCapacitacion();
    }, [slug]);

    if (!singleCapacitacion) {
        if (error) {
            return <div>Error al cargar la capacitación: {error}</div>;
        }
        return <div>Cargando ...</div>;
    }

    const esFechaPasada = (fechaStr) => {
        const fecha = new Date(fechaStr);
        const ahora = new Date();
        return ahora > fecha;
    };

    const portada = singleCapacitacion.img_portada || 'https://iieg.jalisco.gob.mx/acervo/portal/img_postlink.png';

    return (
        <>
            <Helmet>
                <title>{singleCapacitacion.titulo}</title>
                <meta property="og:title" content={singleCapacitacion.titulo} />
                <meta property="og:description" content={singleCapacitacion.descripcion} />
                <meta property="og:image" content={portada} />
                <meta property="og:url" content={window.location.href} />
                <meta property="og:type" content="article" />
                <meta name="keywords" content={singleCapacitacion.clave} />
                {/* Twitter Cards (Específico para X / Twitter) */}
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:title" content={singleCapacitacion.titulo} />
                <meta name="twitter:description" content={singleCapacitacion.descripcion} />
                <meta name="twitter:image" content={portada} />
            </Helmet>
            <article className='mt-8 relative px-5 xl:px-5 2xl:px-0 extra:max-w-[1980px] extra:mx-auto'>
                <section className="page-header text-center pb-12">
                    <div className="container mx-auto grid md:grid-cols-12 gap-1">  
                        <div className='md:col-span-1 text-left'><BackLink /></div>
                        <div className='md:col-span-11 w-full px-2 md:px-0 md:ml-auto md:mr-0 grid lg:grid-cols-12 mx-auto'>
                            <div className='lg:col-span-3 px-5'>
                                <img src={portada} alt={singleCapacitacion.titulo} />
                            </div>
                            <div className='lg:col-span-9 text-left'>
                                <h1 className='text-44 font-garet-extra mb-4'>{singleCapacitacion.titulo}</h1>
                                
                                <SafeHtml htmlContent={singleCapacitacion.descripcion} className='mt-5 prose max-w-none diez text-22!'/>
                                <div className='mt-5 flex flex-wrap gap-5'>
                                    {singleCapacitacion.archivo && (
                                        <TrackedLink key={singleCapacitacion.id} to={singleCapacitacion.archivo} target="_blank" download>
                                            <span className='rounded-2xl bg-etiqueta-ter text-primary text-14 px-5 py-2'>Descarga el archivo informativo</span>
                                        </TrackedLink>
                                    )}                        
                                    {singleCapacitacion.formulario && !esFechaPasada(singleCapacitacion.fin) ? (
                                        <TrackedLink key={singleCapacitacion.id} to={singleCapacitacion.formulario} target="_blank">
                                            <span className='rounded-2xl bg-etiqueta-ter text-primary text-14 px-5 py-2 border'>Inscribete aquí</span>
                                        </TrackedLink>
                                    ): 
                                        <span className='rounded-2xl bg-etiqueta-ter text-titulo! text-14 px-5 py-2 border'>Convocatoria cerrada</span>
                                    }
                                </div>
                            </div>                            
                        </div>
                    </div>
                </section>


                <section className='lg:w-8/12 mx-auto mb-15'>
                    {singleCapacitacion.Objetivo && (
                    <div className='grid grid-cols-12 sm:gap-1'>
                        <div className='col-span-1'>
                            <img src="" alt="" />
                        </div>
                        <div className='col-span-11'>
                                <div className='flex flex-wrap mb-12.5 gap-1'>
                                {singleCapacitacion.inicio && (
                                <div className='mb-3 lg:pt-4'>
                                    <p className='rounded-2xl bg-etiqueta-sec text-tertiary font-garet-bold border text-26 px-5 py-2'>
                                        Inicio de clases: {dayjs(singleCapacitacion.inicio).format('D [de] MMMM [de] YYYY')}                             
                                    </p>
                                </div>
                                )}
                                {singleCapacitacion.formato && (
                                <div className='mb-3 lg:pt-4'>
                                    <p className='rounded-2xl bg-etiqueta-ter text-titulo! text-26 font-garet-bold border px-5 py-2'>
                                        Formato: {singleCapacitacion.formato}
                                    </p>
                                </div>
                                )}
                                {singleCapacitacion.Horario && (
                                <div className='mb-3 lg:pt-4'>
                                    <p className='rounded-2xl bg-etiqueta text-primary text-26 font-garet-bold border px-5 py-2'>
                                        Horario: {singleCapacitacion.Horario}
                                    </p>
                                </div>
                                )}
                            </div>
                            <h2 className='text-primary text-36 font-garet-extra'>Objetivo</h2>                            
                        </div>
                        <SafeHtml htmlContent={singleCapacitacion.Objetivo} className='text-titulo! text-22! mt-5 prose max-w-none cursos bg-card p-6 rounded-xl col-span-12'/>
                    </div>
                    )}
                    {singleCapacitacion.p_ingreso && (
                    <div className='my-20 grid grid-cols-12 gap-5'>
                        <div className='col-span-1'>
                            <img src="" alt="" />
                        </div>
                        <div className='col-span-11'>
                            <h2 className='text-primary text-36 font-garet-extra'>Perfil de Ingreso</h2>                            
                        </div>
                        <SafeHtml htmlContent={singleCapacitacion.p_ingreso} className='text-titulo! text-22! mt-5 prose max-w-none cursos bg-card p-6 rounded-xl col-span-12'/>
                    </div>
                    )}
                    {singleCapacitacion.p_egreso && (
                     <div className='grid grid-cols-12 gap-5'>
                        <div className='col-span-1'>
                            <img src="" alt="" />
                        </div>
                        <div className='col-span-11'>
                            <h2 className='text-primary text-36 font-garet-extra'>Perfil de Egreso</h2>                            
                        </div>
                        <SafeHtml htmlContent={singleCapacitacion.p_egreso} className='text-titulo! text-22! mt-5 prose max-w-none cursos bg-card p-6 rounded-xl col-span-12'/>
                    </div>
                    )}
                </section>
                    
                <CapacitacionesList curso={singleCapacitacion} />

                <section className='grid grid-cols-12 gap-4 lg:w-8/12 mx-auto mb-15'>
                    <div className='col-span-1'></div>
                    <div className='col-span-11 grid lg:grid-cols-2 gap-5'>
                        {singleCapacitacion.inscripcion && (
                        <div className='my-5 bg-card p-6 rounded-xl'>
                            <strong className='text-primary font-garet-extra text-36 mb-10'>Inscripción</strong> 
                            <SafeHtml htmlContent={singleCapacitacion.inscripcion} className='text-titulo! text-20! mt-5 prose max-w-none cursos'/>                                                    
                        </div>
                        )}
                        {singleCapacitacion.acreditacion && (
                        <div className='my-5 bg-card p-6 rounded-xl'>
                            <strong className='text-primary font-garet-extra text-36 mb-10'>Acreditación</strong> 
                            <SafeHtml htmlContent={singleCapacitacion.acreditacion} className='text-titulo! text-20! mt-5 prose max-w-none cursos'/>                        
                        </div>
                        )}
                        {singleCapacitacion.vigencia && (
                        <div className='my-5 bg-card p-6 rounded-xl'>
                            <strong className='text-primary font-garet-extra text-36'>Vigencia</strong> 
                            <p className='text-titulo! text-20! pt-6'>{singleCapacitacion.vigencia}</p>
                        </div>
                        )}
                        {singleCapacitacion.contacto && (
                        <div className='my-5 bg-card p-6 rounded-xl'>
                            <strong className='text-primary font-garet-extra text-36'>Contacto</strong> 
                            <p className='text-titulo! text-20! textpt-6'>{singleCapacitacion.contacto}</p>
                        </div>
                        )}
                        {singleCapacitacion.clave && (
                        <div className='my-5 bg-card p-6 rounded-xl'>
                            <strong className='text-primary font-garet-extra text-36'>Clave</strong> 
                            <p className='text-titulo! text-20! pt-6'>{singleCapacitacion.clave}</p>
                        </div>
                        )}
                    </div>                    
                </section>
                    
            </article>
        </>
    );
}