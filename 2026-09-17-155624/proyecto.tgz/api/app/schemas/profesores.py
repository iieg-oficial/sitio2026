from typing import List, Optional

from pydantic import BaseModel


class ProfesoresCreate(BaseModel):
    nombre: str
    puesto: Optional[str]
    descripcion: Optional[str]
    foto: str | None = None
    slug: Optional[str] = None

class ProfesoresOut(BaseModel):
    id: int
    nombre: str
    puesto: Optional[str]
    descripcion: Optional[str]
    foto: str | None = None
    slug: Optional[str] = None

    class Config:
        from_attributes = True

class ProfesoresResponse(BaseModel):
    profesores: List[ProfesoresOut]
    total: int

    class Config:
        from_attributes = True
